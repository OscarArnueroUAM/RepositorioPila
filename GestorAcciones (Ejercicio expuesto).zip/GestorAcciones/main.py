from historial import HistorialAcciones

def mostrar_menu():
    print("\nMenú de historial de acciones:")
    print("1. Agregar acción")
    print("2. Deshacer")
    print("3. Rehacer")
    print("4. Mostrar historial completo")
    print("5. Salir")

print("Iniciando programa de historial de acciones...")
historial = HistorialAcciones()

while True:
    mostrar_menu()
    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        desc = input("Descripción de la acción: ")
        historial.agregar_accion(desc)
        print(f"Acción agregada: {desc}")

    elif opcion == "2":
        resultado = historial.deshacer()
        print(f"Se deshizo: {resultado}" if resultado else "No hay acciones para deshacer.")

    elif opcion == "3":
        resultado = historial.rehacer()
        print(f"Se rehizo: {resultado}" if resultado else "No hay acciones para rehacer.")

    elif opcion == "4":
        acciones = historial.mostrar_historial()
        print("Historial completo:")
        for idx, a in enumerate(acciones, 1):
            print(f"{idx}. {a}")

    elif opcion == "5":
        print("Saliendo.")
        break

    else:
        print("Opción inválida. Intente de nuevo.")