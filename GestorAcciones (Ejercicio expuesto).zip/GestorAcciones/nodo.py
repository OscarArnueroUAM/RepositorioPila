from accion import Accion

class Nodo:

   # Nodo de una lista doblemente enlazada que almacena una acción.

    def __init__(self, accion: Accion):
        self.accion = accion
        self.prev = None
        self.next = None