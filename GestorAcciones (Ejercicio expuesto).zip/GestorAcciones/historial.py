from nodo import Nodo
from accion import Accion

class HistorialAcciones:

    # Gestión del historial de acciones mediante lista doblemente enlazada.
    # Permite añadir acciones, deshacerlas (con eliminación) y rehacer la última acción deshecha.

    def __init__(self):
        self.cabeza = None
        self.cola = None
        self.actual = None
        self.pila_rehacer = []  # Pila para almacenar la última acción deshecha

    def agregar_accion(self, descripcion: str):

        # Añade una nueva acción al historial. Borra cualquier posibilidad de rehacer.

        nuevo = Nodo(Accion(descripcion))
        self.pila_rehacer.clear()  # Al agregar nueva acción, limpiar pila de rehacer

        if self.cabeza is None:
            self.cabeza = self.cola = self.actual = nuevo
            return

        if self.actual and self.actual.next:
            temp = self.actual.next
            while temp:
                siguiente = temp.next
                temp.prev = temp.next = None
                temp = siguiente
            self.actual.next = None
            self.cola = self.actual

        nuevo.prev = self.cola
        self.cola.next = nuevo
        self.cola = nuevo
        self.actual = nuevo

    def deshacer(self):

        # Deshace la acción más reciente y la guarda para poder rehacerla después.

        if self.actual:
            descripcion = self.actual.accion.descripcion
            nodo_a_eliminar = self.actual

            # Guardamos la acción en la pila para rehacer
            self.pila_rehacer.append(nodo_a_eliminar.accion.descripcion)

            if nodo_a_eliminar == self.cabeza and nodo_a_eliminar == self.cola:
                self.cabeza = self.cola = self.actual = None
            elif nodo_a_eliminar == self.cola:
                self.cola = nodo_a_eliminar.prev
                if self.cola:
                    self.cola.next = None
                self.actual = self.cola
            elif nodo_a_eliminar == self.cabeza:
                self.cabeza = nodo_a_eliminar.next
                if self.cabeza:
                    self.cabeza.prev = None
                self.actual = None
            else:
                nodo_a_eliminar.prev.next = nodo_a_eliminar.next
                nodo_a_eliminar.next.prev = nodo_a_eliminar.prev
                self.actual = nodo_a_eliminar.prev

            nodo_a_eliminar.prev = nodo_a_eliminar.next = None
            return descripcion
        return None

    def rehacer(self):

      # Rehace la última acción deshecha, si hay alguna.

        if self.pila_rehacer:
            descripcion = self.pila_rehacer.pop()
            self.agregar_accion(descripcion)
            return descripcion
        return None

    def mostrar_historial(self):

        # Retorna todas las acciones en orden.

        acciones = []
        nodo = self.cabeza
        while nodo:
            acciones.insert(len(acciones), nodo.accion.descripcion)
            nodo = nodo.next
        return acciones

    def __repr__(self):
        return f"Historial({self.mostrar_historial()})"