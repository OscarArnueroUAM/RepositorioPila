class Accion:

    # Representa una acción en el editor de texto (escribir, borrar, pegar, copiar).

    def __init__(self, descripcion: str):
        self.descripcion = descripcion

    def __repr__(self):
        return f"Accion({self.descripcion!r})"