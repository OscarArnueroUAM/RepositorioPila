def convertir_a_binario(numero):
    pila = []

    # Proceso para convertir a binario usando insert
    if numero == 0:
        pila.insert(0, 0)  # Si el número es 0, insertamos el 0 en la pila
    else:
        while numero > 0:
            residuo = numero % 2
            pila.insert(0, residuo)  # Insertamos al inicio
            numero = numero // 2

    # Convertimos la pila
    binario = ''.join(str(bit) for bit in pila)  # Unimos los bits en una cadena
    return binario