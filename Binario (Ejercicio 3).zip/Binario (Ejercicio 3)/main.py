import conversion

def main():
    numero = 12  # Se puede cambiar este número para probar con otros valores
    binario = conversion.convertir_a_binario(numero)
    print(f"[{binario}]")  # Salida esperada: [1100]

if __name__ == "__main__":
    main()